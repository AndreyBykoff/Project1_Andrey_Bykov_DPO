#!/usr/bin/env python3
def main():
    print("Первый запуск проекта!")